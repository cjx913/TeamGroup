CREATE TRIGGER TRI_CHATMESSAGEID_INCSERT
BEFORE INSERT
  ON CHATMESSAGE
FOR EACH ROW
  begin
    select SEQ_CHATMESSAGEID.nextval into :new.MESSAGEID from dual;
  end tri_chatmessageid_incsert;
/
