CREATE TRIGGER TRI_USERID_INCSERT
BEFORE INSERT
  ON USERS
FOR EACH ROW
  begin
    select SEQ_USERID.nextval into :new.USER_ID from dual;
  end tri_userid_incsert;
/
