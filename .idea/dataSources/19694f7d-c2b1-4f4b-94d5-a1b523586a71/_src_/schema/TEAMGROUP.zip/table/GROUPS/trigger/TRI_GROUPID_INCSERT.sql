CREATE TRIGGER TRI_GROUPID_INCSERT
BEFORE INSERT
  ON GROUPS
FOR EACH ROW
  begin
    select SEQ_GROUPID.nextval into :new.GROUP_ID from dual;
  end tri_groupid_incsert;
/
