CREATE package drixmd authid definer is

  VERSION_LATEST constant number := 8130;
  VERSION_CEILING constant number   := 32000;

/*---------------------------- SetActiveIndex  ---------------------------*/

procedure SetActiveIndex(
  p_idxid           in number
);

/*---------------------------- CheckAccess  ------------------------------*/

procedure CheckAccess(
  p_invoker         in number,
  p_idxid           in number
);


/*------------------------- CheckIndexQueryable  -------------------------*/
/* call before attempting query operation on an index */

procedure CheckIndexQueryable(
  p_idxid           in number
);

/*---------------------------- GetIndexMD  -------------------------------*/
/* fetch selected dr$index column values into out variables */

procedure GetIndexMD(
  p_idxid           in  number,
  o_owner           out varchar2,
  o_owner#          out number,
  o_name            out varchar2,
  o_table_obj#      out number,
  o_table_dataobj#  out number,
  o_key_name        out varchar2,
  o_key_type        out binary_integer,
  o_text_name       out varchar2,
  o_text_type       out binary_integer,
  o_text_length     out binary_integer,
  o_lang_col        out varchar2,
  o_fmt_col         out varchar2,
  o_cset_col        out varchar2,
  o_idx_type        out binary_integer,
  o_idx_option      out varchar2,
  o_idx_sync_type   out varchar2,
  o_idx_sync_memory out binary_integer,
  o_idx_src_name  out varchar2,
  o_idx_src_id    out binary_integer,
  o_idx_version   out binary_integer
);

/*---------------------------- GetIndexID  -------------------------------*/
/* get index id by name */

FUNCTION GetIndexID(
  p_idx_name in varchar2
) return number;

/*---------------------------- FastGetIndexID  ---------------------------*/
/* get index id by owner, name */

FUNCTION FastGetIndexID(
  p_idx_owner in varchar2,
  p_idx_name  in varchar2
) return number;

/*--------------------------- GetIndexRec  -------------------------------*/
/* get index meta data as a record */

POL_INDEX_ONLY      constant number := 0;
POL_POLICY_ONLY     constant number := 1;
POL_INDEX_OR_POLICY constant number := 2;

SEC_NONE            constant number := 0;
SEC_CONTAINS        constant number := 1;
SEC_OWNER           constant number := 2;
SEC_ALTER           constant number := 3;
SEC_DROP            constant number := 4;

FUNCTION GetIndexRec(
  p_idx_name in varchar2,
  f_ispolicy in number    default POL_INDEX_ONLY,
  f_security in number    default SEC_CONTAINS
) return dr_def.idx_rec;

/*--------------------------- ImportingIndex  ----------------------------*/
/* return true if the index name is in import state */
/* note: pass in simple name.  owner is implied -SESSIONID */

FUNCTION ImportingIndex(
  p_idx_name  in varchar2
) return boolean;

/*----------------------- GetIndexStorage  -----------------------*/
/* get index storage clauses */

STO_I   constant number := 1;
STO_R   constant number := 2;
STO_K   constant number := 3;
STO_N   constant number := 4;
STO_P   constant number := 5;
STO_X   constant number := 6;
STO_RX  constant number := 7;
STO_S   constant number := 8;
STO_BI  constant number := 9;
STO_SO  constant number := 10;
STO_M   constant number := 11;
STO_RT  constant number := 12;
STO_G   constant number := 13;
STO_H   constant number := 14;
STO_A   constant number := 15;
STO_F   constant number := 16;

PROCEDURE GetIndexStorage(
  p_idxid    in  number,
  p_ixpid    in  number,
  o_clause   in out dr_def.vc500_tab
);

/*------------------------- GetIndexRecByID  -----------------------------*/
/* get index meta data as a record */

FUNCTION GetIndexRecByID(
  p_idxid    in number
) return dr_def.idx_rec;

/*---------------------------- GetPartitionRec ---------------------------*/
/* get partition meta data as a record */

FUNCTION GetPartitionRec(
  p_ixp_name in varchar2,
  p_idx      in dr_def.idx_rec
) return dr_def.ixp_rec;

/*-------------------------- GetPartitionRecByID -------------------------*/
/* get partition meta data as a record */

FUNCTION GetPartitionRecByID(
  p_ixpid in number,
  p_idxid in number
) return dr_def.ixp_rec;

/*---------------------------- GetPartitionID ---------------------------*/
/* get partition ID */

FUNCTION GetPartitionID(
  p_ixp_name in varchar2,
  p_idxid    in number
) return number;

/*---------------------------- GetAllPartitions ---------------------------*/
/* get all partition metadata in a table */

PROCEDURE GetAllPartitions(
  p_idxid    in number,
  p_idxtab#  in number,
  o_ixp      in out nocopy dr_def.ixp_tab
);

/*---------------------------- GetIndexPartition  -----------------------*/
/* get dr$index_partition information */

procedure GetIndexPartition(
  o_id               out number,
  o_tabpart_dataobj# out number,
  o_sync_type        out varchar2,
  o_sync_memory      out number,
  o_option           out varchar2,
  i_cid               in number,
  i_pname             in varchar2
);

/*---------------------------- OpenIndexMDScan ----------------------*/
/* open dr$index_object/dr$index_value cursors */

procedure OpenIndexMDScan(
  p_idxid           in  number
);

/*---------------------------- NextIndexObject ---------------------------*/
/* get next dr$index_object cursor */

function NextIndexObject(
  o_cla_id          out binary_integer,
  o_obj_id          out binary_integer,
  o_acnt            out binary_integer
) return binary_integer;

/*---------------------------- GetIndexObject ----------------------------*/
/* get a single object id */

PROCEDURE GetIndexObject(
  p_idxid           in  number,
  p_cla_id          in  binary_integer,
  o_obj_id          out binary_integer,
  o_acnt            out binary_integer
);

/*-------------------------- GetAllIndexObjects ----------------------------*/
/* get the index objects as a table */

PROCEDURE GetAllIndexObjects(
  p_idxid           in  number,
  o_objs            in out nocopy dr_def.ixo_tab
);

/*---------------------------- NextIndexValue ----------------------------*/
/* get next dr$index_value cursor */

function NextIndexValue(
  o_cla_id          out binary_integer,
  o_att_id          out binary_integer,
  o_datatype        out binary_integer,
  o_sub_group       out binary_integer,
  o_sub_att_id      out binary_integer,
  o_sub_datatype    out binary_integer,
  o_value           out varchar2
) return binary_integer;

/*---------------------------- NextIndexCDI ---------------------------*/
/* get next dr$index_cdi_column cursor */

function NextIndexCDI(
  o_cdi_pos         out binary_integer,
  o_cdi_type#       out binary_integer,
  o_cdi_len         out binary_integer,
  o_cdi_name        out varchar2,
  o_cdi_sec         out varchar2,
  o_cdi_stype       out binary_integer,
  o_cdi_id          out binary_integer
) return binary_integer;

/*---------------------------- GetDocidCount -----------------------------*/
/* get docid count */

function GetDocidCount(
  p_idxid           in number,
  p_ixpid           in number default null
) return number;

/*---------------------------- GetNextid  -----------------------------*/
/* get next docid */

function GetNextid(
  p_idxid           in number,
  p_ixpid           in number default null
) return number;

/*---------------------------- GetIndexStats -----------------------------*/
/* get index stats from dr$stats */

procedure GetIndexStats(
  p_idxid           in number,
  p_smplsz          in out nocopy number
);

/*---------------------------- GetBaseTableName --------------------------*/
/* get base table name */

procedure GetBaseTableName(
  p_idxid           in number,
  p_ixpid           in number,
  o_objname         out varchar2
);

/*---------------------------- IncrementDocCnt --------------------------*/
/* increment docid count */

procedure IncrementDocCnt(
  p_idxid           in number,
  p_ixpid           in number,
  p_delta           in number
);

/*---------------------------- DecrementDocCnt --------------------------*/
/* decrement docid count */

procedure DecrementDocCnt(
  p_idxid           in number,
  p_ixpid           in number,
  p_delta           in number
);

/*---------------------------- AllocateDocids ---------------------------*/
/* allocate docids */

procedure AllocateDocids(
  p_idxid           in  number,
  p_ixpid           in  number,
  p_allocsz         in  binary_integer,
  p_startid         out number
);

/*--------------------------- IncrementVersion ------------------------------*/
/* increment version of index */
procedure IncrementVersion(
  p_idxid in number,
  p_trynotauto in out boolean
);

/*--------------------------- IncrementVersion_notauto ---------------------*/
/* Non-autonomous txn version of IncrementVersion */
procedure IncrementVersion_notauto(
  p_idxid in number
);

/*---------------------------- SetIndexStatus --------------------------*/
/* set index status */

  STATE_NO_INDEX       constant varchar2(10) := 'NO_INDEX';
  STATE_POPULATE       constant varchar2(10) := 'POPULATE';
  STATE_POPULATE_K     constant varchar2(10) := 'POPULATE_K';
  STATE_PART_BUILD     constant varchar2(10) := 'PARTBUILD';
  STATE_INDEXING       constant varchar2(10) := 'INDEXING';
  STATE_INDEXED        constant varchar2(10) := 'INDEXED';
  STATE_UPGRADING      constant varchar2(10) := 'UPGRADING';
  STATE_IMPORT         constant varchar2(10) := 'IMPORT';
  STATE_SCH_SYNC       constant varchar2(10) := 'SCHE_SYNC';
  STATE_POPULATE_P     constant varchar2(10) := 'POPULATE_P';

procedure SetIndexStatus(
  p_idxid           in  number,
  p_ixpid           in  number,
  p_status          in  varchar2,
  f_commit          in  boolean default TRUE
);

/*---------------------------- GetIndexStatus  -----------------------*/
/* get index status */

FUNCTION GetIndexStatus(
   p_idxid     in  number
 ) return VARCHAR2;

/*---------------------------- ChangeIndexOption -----------------------*/
/* modify the index option field */

  OPT_SET    constant number := 0;
  OPT_ADD    constant number := 1;
  OPT_REMOVE constant number := 2;

PROCEDURE ChangeIndexOption (
  p_idxid     in number,
  p_opt       in varchar2,
  p_action    in number,
  p_ixpid     in number default 0
);

/*----------------------------- AllocatePartId ---------------------------*/
/* Allocate index partition id                                            */

FUNCTION AllocatePartId(
  idxid           in    number
) return number;

/*----------------------------- CreatePartitionMD  -----------------------*/
/* set up partition meta-data */

PROCEDURE CreatePartitionMD(
  p_idxid         in     number,
  p_ixpid         in out number,
  p_idx_partition in     varchar2,
  p_table_owner   in     varchar2,
  p_table_name    in     varchar2,
  p_tab_partition in     varchar2,
  p_storage       in     varchar2,
  p_sync_type     in out varchar2,
  p_sync_memory   in out varchar2,
  p_sync_paradegree  in out number,
  p_sync_interval    in out varchar2,
  is_online          in boolean default FALSE,
  p_sync_dpl         in boolean default FALSE
);

/*----------------------------- DropPartitionMD  --------------------------*/
/* drop partition meta-data */

PROCEDURE DropPartitionMD(
  p_idxid         in     number,
  p_ixpid         in     number
);

/*---------------------------- PurgeKGL ----------------------------------*/
/* purge KGL metadata cache */

PROCEDURE PurgeKGL(p_idxid in number, ia sys.odciindexinfo,
                   isPart boolean default FALSE);

PROCEDURE PurgeKGL(p_idx in dr_def.idx_rec);

PROCEDURE PurgeKGL(p_idxid in number, owner in varchar2,
                   index_name in varchar2,
                   other_name in varchar2 default NULL);

/*---------------------------- CreatePolicy ------------------------------*/
/* create policy */

  IDX_TYPE_CONTEXT     constant number := 0;
  IDX_TYPE_CTXCAT      constant number := 1;
  IDX_TYPE_CTXRULE     constant number := 2;
  IDX_TYPE_CTXXPATH    constant number := 3;

PROCEDURE CreatePolicy(
    ia              in  sys.ODCIIndexInfo,
    p_idx_type      in  number,
    p_idx_owner     in  varchar2,
    p_idx_name      in  varchar2,
    p_tab_owner     in  varchar2,
    p_tab_name      in  varchar2,
    p_col_name      in  varchar2,
    p_col_type      in  varchar2,
    p_lang_col      in  varchar2,
    p_fmt_col       in  varchar2,
    p_cset_col      in  varchar2,
    p_idx_id        out number,
    p_dstore        in  varchar2 default null,
    p_filter        in  varchar2 default null,
    p_secgrp        in  varchar2 default null,
    p_lexer         in  varchar2 default null,
    p_wordlist      in  varchar2 default null,
    p_stoplist      in  varchar2 default null,
    p_storage       in  varchar2 default null,
    p_indexset      in  varchar2 default null,
    p_classifier    in  varchar2 default null,
    p_txntional     in  varchar2 default null,
    p_sync_type     in out varchar2,
    p_sync_memory   in out varchar2,
    p_sync_paradegree  in out number,
    p_sync_interval    in out varchar2,
    f_partitioned   in  boolean  default FALSE,
    f_functional    in  boolean  default FALSE,
    f_online        in  boolean  default FALSE,
    f_entity_policy in  boolean  default FALSE,
    f_tree          in  boolean  default FALSE,
    p_sync_dpl      in  boolean  default FALSE
);

/*---------------------------- CopyPolicy ----------------------------------*/
/* copy index-level meta-data */

PROCEDURE CopyPolicy(
    p_source_policy  in varchar2,
    p_pol_owner      in varchar2,
    p_pol_name       in varchar2
);

/*---------------------------- DropPolicy ----------------------------------*/
/* drop index-level meta-data */

PROCEDURE DropPolicy(
    p_idxid in number
);

/*---------------------------- DropUserPolicies ----------------------------*/

PROCEDURE DropUserPolicies(
  p_username in varchar2 := null
);

/*----------------------------- ResetIndexIDs  -----------------------------*/
/* reset owner and table id's during an import */

PROCEDURE ResetIndexIDs (
    p_idxid     out number,
    p_owner     in  varchar2,
    p_idx_name  in  varchar2,
    p_tab_owner in  varchar2,
    p_tab_name  in  varchar2,
    p_ipar_name in  varchar2 default null,
    p_tab_part  in  varchar2 default null
);

/*---------------------------- IndexHasPTable ------------------------------*/

FUNCTION IndexHasPTable(
  p_idxid in number)
RETURN boolean;

/*---------------------------- IndexHasSTable ------------------------------*/

FUNCTION IndexHasSTable(
  p_idxid in number)
RETURN boolean;

/*---------------------------- IndexHasMTable ------------------------------*/

FUNCTION IndexHasMTable(
  p_idxid in number)
RETURN boolean;

/*---------------------------- IndexHasFATables ----------------------------*/

FUNCTION IndexHasFATables(
  p_idxid in number)
RETURN boolean;

/*---------------------------- IndexHasMVDATA ------------------------------*/

FUNCTION IndexHasMVDATA(
  p_idxid in number)
RETURN boolean;

/*---------------------------- IndexHasGTable ------------------------------*/

FUNCTION IndexHasGTable(
  p_idxid in number)
RETURN boolean;

/*----------------------  CheckIndexesForExchange --------------------------*/
/* ensure that a global index and an index partition are compatible for */
/* exchange partition operation */

PROCEDURE CheckIndexesForExchange(
  p_idxp  in dr_def.idx_rec,
  p_idxn  in dr_def.idx_rec
);

/*--------------------------- ExchangeIndexMD ---------------------------*/
/* exchange meta data */

procedure ExchangeIndexMD(
  p_idxn   in dr_def.idx_rec,
  p_idxpid in number,
  p_ixpp   in dr_def.ixp_rec
);

/*--------------------------- RenameIndex -------------------------------*/
/* rename an index */

procedure RenameIndex(
  p_idxid   in number,
  p_ixpid   in number,
  p_newname in varchar2
);

/*--------------------------- RenameIndexCol ----------------------------*/
/* rename index column */

procedure RenameIndexCol(
  p_idxid   in number,
  p_newname in varchar2
);

/*--------------------------- GetAllPartitionIDs ------------------------*/
/* get all partition id's */

procedure GetAllPartitionIDs(
  p_idxid   in number,
  o_ids     out nocopy dr_def.id_tab
);

/*--------------------------- GetAllPartitionOPTs ------------------------*/
/* get all partition option's */

procedure GetAllPartitionOPTs(
  p_idxid   in number,
  o_opts    out nocopy dr_def.vc256_tab
);

/*--------------------------- GetAllPartitionNMs ------------------------*/
/* get all index partition names */

procedure GetAllPartitionNMs(
  p_idxid   in number,
  o_names   out nocopy dr_def.vc30_tab
);

/*--------------------------- SetIndexMD --------------------------------*/
/* change a field of index meta-data */

  MDF_LANGCOL constant number := 0;
  MDF_FMTCOL  constant number := 1;
  MDF_CSETCOL constant number := 2;
  MDF_NEXTID  constant number := 3;
  MDF_SYNC_TYPE        constant  number := 4;
  MDF_SYNC_MEMSIZE     constant  number := 5;
  MDF_SYNC_PARADEGREE  constant  number := 6;
  MDF_SYNC_INTERVAL    constant  number := 7;

procedure SetIndexMD(
  p_idxid   in number,
  p_ixpid   in number,
  p_field   in binary_integer,
  p_newval  in varchar2,
  f_commit  in boolean default TRUE
);

/*--------------------------- CreateSQE ----------------------------------*/
/* create a new SQE (should be in its own package, like drisgp or drispl, */
/* but this is only two procedures)                                       */

procedure CreateSQE(
  p_sqe   in varchar2
 ,p_query in clob
 ,p_duration in number
);

/*--------------------------- DropSQE -----------------------------------*/
/* drop SQE */

procedure DropSQE(
  p_sqe   in varchar2
);

/*--------------------------- DropUserSQEs ---------------------------------*/
/* Drop SQE's owned by a user, or all unreferenced SQEs if p_username is    */
/* null                                                                     */

procedure DropUserSQEs(
  p_username in varchar2 := null
);


/*--------------------------- GetSysParam ----------------------------------*/
/* get value of system parameter (should be in something like driadm, but */
/* this is only one procedure... */

function GetSysParam (
  p_param in varchar2
) return varchar2;

/*---------------------------- RecordJob ----------------------------------*/
/*record the job name in dr$index                                          */

procedure RecordJob (
  idxid     in  number,
  ixpid     in  number default null,
  jobname   in  varchar2
);

/*--------------------------- GetJob ------------------------------------*/
/* Remove the job                                                         */
function GetJob (
  idxid    in number,
  ixpid    in number default NULL
) return varchar2;

/*--------------------------- SetSyncAttr-------------------------------*/
procedure SetSyncAttr(
  idxid   in number,
  ixpid   in number,
  sync_type       in varchar2,
  sync_memory     in varchar2,
  sync_paradegree in number,
  sync_interval   in varchar2
);

/*--------------------------- GetSyncAttr-------------------------------*/
procedure GetSyncAttr(
  idxid           in  number,
  ixpid           in  number default null,
  sync_type       out varchar2,
  sync_memory     out varchar2,
  sync_paradegree out number,
  sync_interval   out varchar2,
  sync_jobname    out varchar2
) ;

/*---------------------- CheckIndexForOraCon  -----------------------------*/
/*compare a policy and index and determine if they are close enough        */

function CheckIndexForOraCon (
  p_idxid   in  number,
  p_polid   in  number
) return number;


/*---------------------- OraConRewriteChk  -----------------------------*/
/* Checks to see if a Text index and Text query qualifies for           */
/* Ora:Contains() query rewrite.                                        */

function OraConRewriteChk (
  p_idxname   in  varchar2,
  p_idxown    in  varchar2,
  p_polname   in  varchar2,
  p_polown    in  varchar2,
  p_qry       in  varchar2
) return boolean;


/*---------------------- IndexHasPendingRows  --------------------------*/
/* Checks to see if a Text index currently has pending rows             */

function IndexHasPendingRows (
  p_idxid in number)
return boolean;

/*---------------------- GetMVFlag -------------------------------------*/
/*  checkto see if index is on Materialized view                        */

procedure GetMVFlag(
  table_id     in number,
  owner_name   in varchar2,
  opt          out binary_integer
);

/*---------------------------- CopyIndexMDRIO ---------------------------*/
/* copy index meta-data for Recreate Index Online */

PROCEDURE CopyIndexMDRIO(
    p_src  in dr_def.idx_rec,
    p_dst  in out nocopy dr_def.idx_rec,
    p_create  in boolean
);

PROCEDURE CopyPartMDRIO(
    ixp    in dr_def.ixp_rec,
    idx    in dr_def.idx_rec,
    p_create  in boolean
);

/*---------------------------- GetAllCDIColumns ---------------------------*/

PROCEDURE GetAllCDIColumns(
  p_idxid in number,
  o_cdi   in out nocopy dr_def.cdi_tab
);

/*---------------------------- UpdateSDATA ---------------------------*/

PROCEDURE UpdateSDATA(
  p_idxid    in number,
  p_ixpid    in number,
  p_docid    in number,
  p_sdata_id in number,
  p_dtype    in varchar2,
  p_nval     in sys.anydata
);

/*---------------------------- ChkIndexOption -----------------------------*/
/*
  Take in index id, and an option letter (see drdmlop() for a list of
  options), return 1 if the given option is set, 0 otherwise.
*/
function ChkIndexOption (
  p_idxid  in number,
  p_opt    in varchar2
) return number;

/*--------------------------- CompareIndexObjectValuesPref -----------------*/
/*
 * compare the attribute values of a single class between an index and a
 * preference name. return the actual differences in a table of type ixo_tab
*/

procedure CompareIndexObjectValuesPref(
  p_idxid in number,
  p_pref  in varchar2,
  p_cla_id in number,
  diffs   in out dr_def.ixv_tab
);

/*--------------------------- RemoveStageItab ------------------------------*/
/* remove stage_itab from dr$index_value without modifying storage pref */
procedure RemoveStageItab(
  p_idxid in number);

/*--------------------------- AddStageItab ---------------------------------*/
/* add stage_itab from dr$index_value without modifying storage pref */
procedure AddStageItab(
  p_idxid in number);

/*--------------------------- GetFieldFid ---------------------------------*/
/* Given a field section name and tag, find its FID */
procedure GetFieldFid(
  idxid in number,
  fld_name in varchar2,
  fld_tag in varchar2,
  fldfid out number);

/*--------------------------- RemZoneFromMD -------------------------------*/
/* Given an Index ID remove Zone sections from Index Metadata */
procedure RemZoneFromMD(
  idxid in number,
  zone_name in varchar2,
  zone_tag in varchar2);

/*--------------------------- check_auto_optimize --------------------------*/
/* is this index subject to auto_optimize */
CheckAutoOptimizeOK      constant number := 0;
CheckAutoOptimizeDisable constant number := 1;
CheckAutoOptimizeRunning constant number := 2;
CheckAutoOptimizeNotReg  constant number := 3;
CheckAutoOptimizeConcOpt constant number := 4;

function check_auto_optimize(p_idx in dr_def.idx_rec,
                             p_ixp in dr_def.ixp_rec,
                             p_override in boolean default false)
return number;

/*--------------------------- start_auto_optimize --------------------------*/
/* start an auto_optimize job */
procedure start_auto_optimize;

/*--------------------------- stop_auto_optimize ---------------------------*/
/* forcibly stop an auto_optimize job */
procedure stop_auto_optimize;

/*--------------------------- run_auto_optimize ---------------------------*/
/* actually run an auto_optimize job */
procedure run_auto_optimize;

/*--------------------------- add_auto_optimize ----------------------------*/
/* add an auto optimize index / partition */
procedure add_auto_optimize(p_idx in dr_def.idx_rec,
                            p_ixp in dr_def.ixp_rec);

/*--------------------------- remove_auto_optimize -------------------------*/
/* remove an auto optimize index / partition */
procedure remove_auto_optimize(p_idxid in number,
                               p_partname in varchar2 default null);

/*--------------------------- reset_auto_optimize_status -------------------*/
/* reset the autoopt_status table */
procedure reset_auto_optimize_status;

/*--------------------------- autoopt_push_token --------------------------*/
/* autoopt_push_token - push a token to autooptimize */
procedure autoopt_push_token(p_message in raw);

/*--------------------------- autoopt_pop_token ----------------------------*/
/* autoopt_pop_token - pop a token for autooptimize */
procedure autoopt_pop_token(p_ret out number,
                            p_message out raw);

/*--------------------------- autoopt_cre_pipe -----------------------------*/
/* autoopt_cre_pipe - create a private pipe for autooptimize */
procedure autoopt_cre_pipe(p_ret out number);

/*--------------------------- TxnalGetKey --------------------------------*/
/* Return the key if it has been set.  Use second parameter to test if it
 * has not been set                                                       */

procedure TxnalGetKey(
  p_key in out raw
);

/*--------------------------- TxnalSetKey --------------------------------*/
/* Set the key.  Set flag                                                 */

procedure TxnalSetKey(
  p_key in raw
);

/*--------------------------- GetMultiblockReadCount -----------------------*/
function GetMultiblockReadCount return number;

/*------------------------ GetSLXMdataSecID ------------------------------*/
/* Get section id/token type for DR$ML MDATA section, doc level lexer     */

FUNCTION GetSLXMdataSecID(
  idxid in number
) return number;

/*--------------------------- isSES ----------------------------------------*/
/* This function checks whether we are running as SES */
FUNCTION isSES return boolean;

end drixmd;
/
