CREATE PACKAGE drival AS

function validate_pref(
  p_pref_name varchar2,
  p_class_id  number
) return dr_def.pref_rec;

procedure validate_attr(p_pref        in      dr_def.pref_rec,
                        p_attr_name   in      varchar2,
                        p_attr_value  in out  varchar2);

/*----------------------- ValidateCTXRULEOptions  -----------------------*/
/*
  NAME
    ValidateCTXRULEOptions

  DESCRIPTION
    Validate the attributes used during the construction of a CTXRULE index.
    The invalid attribute value are:
       * PREFIX_INDEX can not be set to TRUE
       * SUBSTRING_INDEX can not be set to TRUE

  ARGUMENTS
    opts - a creation record

  NOTES
    This function was added for Bug 5237224.

  EXCEPTIONS
    DRIG.QE_CTXRULE_INVALIDATTR is raised if an invalid attribute
    value is present.  It has two possible arguments.  These are
    'PREFIX_INDEX' or 'SUBSTRING_INDEX'.

  RETURNS
    0 if the attributes are acceptable
    1 if the attribute settings can not be used in a CTXRULE index.

*/
FUNCTION ValidateCTXRULEOptions (
  opts driparse.createrec
) return number;

end drival;
/
