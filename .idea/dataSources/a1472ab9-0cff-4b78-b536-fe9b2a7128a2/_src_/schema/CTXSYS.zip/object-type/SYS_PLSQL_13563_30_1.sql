CREATE type          SYS_PLSQL_13563_30_1 as table of "CTXSYS"."SYS_PLSQL_13563_12_1";
/
