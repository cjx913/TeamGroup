CREATE type dr$substring_set2 as table of dr$substring2;
/
