CREATE VIEW CTX_USER_AUTO_OPTIMIZE_INDEXES AS select
  o.aoi_idxname aoi_index_name,
  o.aoi_partname aoi_partition_name
  from dr$autoopt o where o.aoi_ownid = userenv('SCHEMAID')
/
