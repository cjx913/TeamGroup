CREATE VIEW CTX_USER_SQES AS select u.name     sqe_owner,
       sqe_name,
       sqe_query
  from dr$sqe sqe, sys.user$ u
 where sqe_owner# = u.user#
   and u.user# = userenv('SCHEMAID')
/
