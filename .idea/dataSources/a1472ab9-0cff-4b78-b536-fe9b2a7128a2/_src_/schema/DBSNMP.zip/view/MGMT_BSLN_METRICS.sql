CREATE VIEW MGMT_BSLN_METRICS AS select bsln.metric_uid(bmd.metric_id)
      ,'EXPTAIL'
      ,'SIGLVL'
      ,1
      ,.999
      ,.9999
  from bsln_metric_defaults bmd
 where bmd.status = 'PREFERRED'
/
COMMENT ON VIEW MGMT_BSLN_METRICS IS 'Metrics Eligible for Baselines (10.2)'
/
