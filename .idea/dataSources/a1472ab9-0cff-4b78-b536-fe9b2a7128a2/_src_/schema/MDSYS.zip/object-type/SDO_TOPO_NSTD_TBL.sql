CREATE TYPE SDO_TOPO_NSTD_TBL
                                                                      
AS TABLE OF NUMBER
/
