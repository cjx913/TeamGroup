CREATE TYPE SDO_VPOINT_TYPE
                                                                      
AS VARRAY(64) OF NUMBER
/
