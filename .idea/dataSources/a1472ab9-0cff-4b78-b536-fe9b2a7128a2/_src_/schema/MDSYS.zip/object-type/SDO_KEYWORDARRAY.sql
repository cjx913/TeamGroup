CREATE type       SDO_keywordArray
                                      
as VARRAY(10000) of VARCHAR2(9000)
/
