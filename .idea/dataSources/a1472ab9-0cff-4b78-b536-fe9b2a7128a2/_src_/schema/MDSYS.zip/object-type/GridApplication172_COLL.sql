CREATE TYPE         "GridApplication172_COLL" AS VARRAY(2147483647) OF "GridApplicationType171_T"
/
