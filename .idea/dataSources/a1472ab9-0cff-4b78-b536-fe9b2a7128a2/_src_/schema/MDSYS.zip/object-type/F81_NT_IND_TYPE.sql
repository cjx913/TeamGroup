CREATE type F81_nt_ind_type as table of F81_index_object;
/
