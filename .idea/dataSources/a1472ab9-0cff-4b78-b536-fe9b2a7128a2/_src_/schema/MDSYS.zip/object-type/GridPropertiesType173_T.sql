CREATE TYPE         "GridPropertiesType173_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","MinCoords" "CoordinatesType165_T","MaxCoords" "CoordinatesType165_T","CoordSpacing" "CoordinatesType165_T","CoordinateUnitOfMeasure" "UnitOfMeasureType161_T")NOT FINAL INSTANTIABLE
/
