CREATE type sdoridtable AS TABLE of VARCHAR2(24);
/
