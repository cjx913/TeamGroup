CREATE TYPE SDO_STRING2_ARRAY
                                                                      
AS VARRAY(2147483647) OF VARCHAR2(4096)
/
