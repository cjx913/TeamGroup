CREATE TYPE SDO_GEOMETRY_ARRAY
                                                                                 
     AS VARRAY(10485760) OF SDO_GEOMETRY
/
