CREATE type vertex_set_type as TABLE of vertex_type;
/
