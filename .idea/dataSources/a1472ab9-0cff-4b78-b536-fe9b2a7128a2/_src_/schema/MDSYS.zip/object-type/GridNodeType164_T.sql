CREATE TYPE         "GridNodeType164_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Offset" "CoordinatesType165_T","OffsetPrecision" "CoordinatesType165_T")NOT FINAL INSTANTIABLE
/
