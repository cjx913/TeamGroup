CREATE TYPE ST_Point_Array
                                      
AS VARRAY(1048576) OF ST_Point
/
