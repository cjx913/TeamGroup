CREATE type AggrConcat AUTHID current_user as Object
(
  context raw(4),
  static function odciaggregateinitialize(sctx IN OUT AggrConcat)
              return PLS_INTEGER,
  member function odciaggregateiterate(self IN OUT AggrConcat,
               geom IN mdsys.SDO_GEOMETRY) return PLS_INTEGER,
  member function odciaggregateterminate(self IN AggrConcat,
                                 returnValue OUT mdsys.sdo_geometry,
                                 flags IN number)
                     return PLS_INTEGER,
  member function odciaggregatemerge(self IN OUT AggrConcat,
                    sctx2 IN  AggrConcat) return PLS_INTEGER);
/
