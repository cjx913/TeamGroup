-- Cannot generate trigger SDO_LRS_TRIG_INS: the table is unknown
/
