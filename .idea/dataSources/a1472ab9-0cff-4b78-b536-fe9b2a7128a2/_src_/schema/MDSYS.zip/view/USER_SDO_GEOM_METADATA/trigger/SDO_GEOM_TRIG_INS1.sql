-- Cannot generate trigger SDO_GEOM_TRIG_INS1: the table is unknown
/
