CREATE TRIGGER "DefaultStyle204_TAB$xd"
AFTER UPDATE OR DELETE
  ON "DefaultStyle204_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','DefaultStyle204_TAB', :old.sys_nc_oid$, 'EFCC6DB39ABD4FA5A490E21874ED8289' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','DefaultStyle204_TAB', :old.sys_nc_oid$, 'EFCC6DB39ABD4FA5A490E21874ED8289', user ); END IF; END;
/
