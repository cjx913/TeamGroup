CREATE TRIGGER "Vis3DConfig219_TAB$xd"
AFTER UPDATE OR DELETE
  ON "Vis3DConfig219_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Vis3DConfig219_TAB', :old.sys_nc_oid$, '77BD298EDE3043A59F188A77216775F6' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Vis3DConfig219_TAB', :old.sys_nc_oid$, '77BD298EDE3043A59F188A77216775F6', user ); END IF; END;
/
