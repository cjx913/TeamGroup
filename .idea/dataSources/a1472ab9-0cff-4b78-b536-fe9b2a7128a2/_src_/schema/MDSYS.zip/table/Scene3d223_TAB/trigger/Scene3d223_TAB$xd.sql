CREATE TRIGGER "Scene3d223_TAB$xd"
AFTER UPDATE OR DELETE
  ON "Scene3d223_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Scene3d223_TAB', :old.sys_nc_oid$, 'D07EBD42E0594D0BB5F2420497F1827D' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Scene3d223_TAB', :old.sys_nc_oid$, 'D07EBD42E0594D0BB5F2420497F1827D', user ); END IF; END;
/
