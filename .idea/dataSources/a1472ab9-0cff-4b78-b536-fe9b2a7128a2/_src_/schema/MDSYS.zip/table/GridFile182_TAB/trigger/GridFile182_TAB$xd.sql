CREATE TRIGGER "GridFile182_TAB$xd"
AFTER UPDATE OR DELETE
  ON "GridFile182_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','GridFile182_TAB', :old.sys_nc_oid$, '11C7A0EF4F1E4B009D05B8C727C8D046' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','GridFile182_TAB', :old.sys_nc_oid$, '11C7A0EF4F1E4B009D05B8C727C8D046', user ); END IF; END;
/
