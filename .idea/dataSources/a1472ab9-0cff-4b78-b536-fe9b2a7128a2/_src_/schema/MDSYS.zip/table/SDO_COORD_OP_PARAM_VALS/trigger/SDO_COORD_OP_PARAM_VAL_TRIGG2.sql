CREATE TRIGGER SDO_COORD_OP_PARAM_VAL_TRIGG2
AFTER INSERT OR UPDATE OR DELETE
  ON SDO_COORD_OP_PARAM_VALS
  BEGIN
  update
    sdo_cs_srs
  set
    wktext = MDSYS.sdo_cs.internal_det_srid_wkt(srid),
    wktext3d = mdsys.sdo_cs.get_3d_wkt(srid)
  where
    wktext = 'Getting updated';
end;
/
