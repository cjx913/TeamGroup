CREATE TRIGGER SDO_COORD_OP_PARAM_VAL_TRIGGER
AFTER INSERT OR UPDATE OR DELETE
  ON SDO_COORD_OP_PARAM_VALS
FOR EACH ROW
  BEGIN
delete from mdsys.sdo_cs_context_information;
  update
    sdo_cs_srs
  set
    wktext = 'Getting updated'
  where
    srid in (
      select
        crs.srid
      from
        sdo_coord_ref_sys crs
      where
        crs.projection_conv_id = :new.coord_op_id);
end;
/
