CREATE TRIGGER "LightSource3d220_TAB$xd"
AFTER UPDATE OR DELETE
  ON "LightSource3d220_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','LightSource3d220_TAB', :old.sys_nc_oid$, 'CD6F5DC8A675459E80B6B39F6F2AD50D' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','LightSource3d220_TAB', :old.sys_nc_oid$, 'CD6F5DC8A675459E80B6B39F6F2AD50D', user ); END IF; END;
/
