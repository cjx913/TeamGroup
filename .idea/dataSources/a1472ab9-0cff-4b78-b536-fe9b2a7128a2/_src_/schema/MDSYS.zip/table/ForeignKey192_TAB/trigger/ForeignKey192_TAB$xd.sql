CREATE TRIGGER "ForeignKey192_TAB$xd"
AFTER UPDATE OR DELETE
  ON "ForeignKey192_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ForeignKey192_TAB', :old.sys_nc_oid$, '357EC43C7A92499B94746222AEFD53A8' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ForeignKey192_TAB', :old.sys_nc_oid$, '357EC43C7A92499B94746222AEFD53A8', user ); END IF; END;
/
