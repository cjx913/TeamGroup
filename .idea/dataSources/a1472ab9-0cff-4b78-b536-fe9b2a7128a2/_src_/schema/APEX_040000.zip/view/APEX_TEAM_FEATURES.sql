CREATE VIEW APEX_TEAM_FEATURES AS select
    w.PROVISIONING_COMPANY_ID     workspace_id,
    w.short_name                  workspace_name,
    --
    f.id                          feature_id,
    f.feature_id                  feature_friendly_id,
    f.feature_name,
    f.feature_owner,
    f.feature_contributor,
    f.focus_area,
    f.release,
    f.feature_desc                feature_description,
    f.justification,
    f.feature_tags,
    f.feature_priority,
    f.feature_status,
    f.feature_desirability,
    f.due_date,
    f.start_date,
    f.module,
    f.estimated_effort_in_hours,
    --
    f.publishable_yn,
    f.publishable_description,
    --
    f.globalization_impact,
    f.globalization_assignee,
    f.globalization_status,
    --
    f.user_interface_impact,
    f.user_interface_assignee,
    f.user_interface_status,
    --
    f.doc_impact,
    f.doc_status,
    f.doc_writer,
    --
    f.testing_impact,
    f.testing_assignee,
    f.testing_status,
    --
    f.security_impact,
    f.security_assignee,
    f.security_status,
    --
    f.accessibility_impact,
    f.accessibility_assignee,
    f.accessibility_status,
    --
    f.application_id,
    f.parent_feature_id,
    f.event_id                    milestone_id,
    --
    f.created_by,
    f.created_on,
    f.updated_by,
    f.updated_on
from
    wwv_flow_features f,
    wwv_flow_companies w
where
    f.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/
COMMENT ON VIEW APEX_TEAM_FEATURES IS 'Items that need to get done - i.e. to dos.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.WORKSPACE_ID IS 'Primary key that identifies the workspace.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.WORKSPACE_NAME IS 'Name of the workspace.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_ID IS 'Primary key of the feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_FRIENDLY_ID IS 'More readable id for the feature (unique within workspace only).'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_NAME IS 'Brief description of the feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_OWNER IS 'Identifies who the feature is assigned to.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_CONTRIBUTOR IS 'Identifies who is contributing to the completion of the feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FOCUS_AREA IS 'Focus area (or category) assigned to this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.RELEASE IS 'Release associated with this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_DESCRIPTION IS 'Detailed description of the feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.JUSTIFICATION IS 'Justification for creating this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_TAGS IS 'Tags associated with this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_PRIORITY IS 'Priority assigned to this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_STATUS IS 'Current status of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.FEATURE_DESIRABILITY IS 'Desirability of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.DUE_DATE IS 'Date this feature is due to be completed.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.START_DATE IS 'Date this feature is due to be started.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.MODULE IS 'Module associated with this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.ESTIMATED_EFFORT_IN_HOURS IS 'Estimate of the number of hours this feature will take to complete.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.PUBLISHABLE_YN IS 'Identifies whether or not this feature is publishable.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.PUBLISHABLE_DESCRIPTION IS 'Description that will be published describing this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.GLOBALIZATION_IMPACT IS 'The globalization impact of this feature, including notes from the review.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.GLOBALIZATION_ASSIGNEE IS 'Person responsible for reviewing the globalization of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.GLOBALIZATION_STATUS IS 'Status of the globalization review of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.USER_INTERFACE_IMPACT IS 'The user interface impact of this feature, including notes from the review.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.USER_INTERFACE_ASSIGNEE IS 'Person responsible for reviewing the user interface of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.USER_INTERFACE_STATUS IS 'Status of the user interface review of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.DOC_IMPACT IS 'Additional information about needed documentation or documentation status.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.DOC_STATUS IS 'Status of documentation for this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.DOC_WRITER IS 'Person responsible to document this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.TESTING_IMPACT IS 'Additional information about needed testing or testing status.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.TESTING_ASSIGNEE IS 'Person responsible to test this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.TESTING_STATUS IS 'Testing status for this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.SECURITY_IMPACT IS 'The security impact of this feature, including notes from the review.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.SECURITY_ASSIGNEE IS 'Person responsible for reviewing the security of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.SECURITY_STATUS IS 'Status of the security review of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.ACCESSIBILITY_IMPACT IS 'The accessibility impact of this feature, including notes from the review.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.ACCESSIBILITY_ASSIGNEE IS 'Person responsible for reviewing the accessibility of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.ACCESSIBILITY_STATUS IS 'Status of the accessibility review of this feature.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.APPLICATION_ID IS 'Associated application.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.PARENT_FEATURE_ID IS 'ID of parent feature (link to feature_id to view hierarchy).'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.MILESTONE_ID IS 'Associated milestone.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.CREATED_BY IS 'Developer who created this milestone.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.CREATED_ON IS 'Date on which this milestone was created.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.UPDATED_BY IS 'Developer who last updated this milestone.'
/
COMMENT ON COLUMN APEX_TEAM_FEATURES.UPDATED_ON IS 'Date on which this milestone was last updated.'
/
