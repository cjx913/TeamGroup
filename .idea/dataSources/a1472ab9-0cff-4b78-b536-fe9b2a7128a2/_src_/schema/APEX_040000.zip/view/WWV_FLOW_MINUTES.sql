CREATE VIEW WWV_FLOW_MINUTES AS select i-1 from wwv_flow_dual100 where i < 61
/
