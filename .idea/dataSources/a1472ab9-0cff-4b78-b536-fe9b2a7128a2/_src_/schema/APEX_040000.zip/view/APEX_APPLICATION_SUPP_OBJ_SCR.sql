CREATE VIEW APEX_APPLICATION_SUPP_OBJ_SCR AS select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    i.NAME                           script_name,
    i.SEQUENCE                       execution_sequence,
    decode(i.SCRIPT_TYPE,
           'UPGRADE','Upgrade',
           'INSTALL','Install',
           i.SCRIPT_TYPE)            script_type,
    --
    i.SCRIPT                         sql_script,
    --
    i.CONDITION_TYPE                 condition_type,
    i.CONDITION                      condition_expression1,
    i.CONDITION2                     condition_expression2,
    --
    i.LAST_UPDATED_BY                last_updated_by,
    i.LAST_UPDATED_ON                last_updated_on,
    i.CREATED_BY                     created_by,
    i.CREATED_ON                     created_on,
    --
    i.ID                             supporting_object_script_id
from wwv_flow_install_scripts i,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.id = i.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_APPLICATION_SUPP_OBJ_SCR IS 'Identifies the Supporting Object installation SQL Scripts'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.SCRIPT_NAME IS 'Identifies the name of the installation SQL Script'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.EXECUTION_SEQUENCE IS 'Identifies the execution of the installation SQL Script'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.SCRIPT_TYPE IS 'Identifies whether this is an install or upgrade SQL Script'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.SQL_SCRIPT IS 'Identifies the SQL Script.  Most basic SQL*plus syntax can be used to create database objects and load sample data.'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.CONDITION_TYPE IS 'Identifies the condition type used to conditionally execute the Installation SQL Script'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.CONDITION_EXPRESSION1 IS 'Specifies an expression based on the specific condition type selected.'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.CONDITION_EXPRESSION2 IS 'Specifies an expression based on the specific condition type selected.'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.LAST_UPDATED_ON IS 'Date of last update'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.CREATED_BY IS 'APEX User Name of the developer who created this SQL Script'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.CREATED_ON IS 'Date that this SQL Script was created'
/
COMMENT ON COLUMN APEX_APPLICATION_SUPP_OBJ_SCR.SUPPORTING_OBJECT_SCRIPT_ID IS 'Primary Key of this SQL Script component'
/
