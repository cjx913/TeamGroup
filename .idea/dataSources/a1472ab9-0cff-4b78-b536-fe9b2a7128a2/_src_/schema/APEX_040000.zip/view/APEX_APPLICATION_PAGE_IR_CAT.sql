CREATE VIEW APEX_APPLICATION_PAGE_IR_CAT AS select
w.short_name         workspace,
f.id                 application_id,
f.name               application_name,
c.worksheet_id       interactive_report_id,
c.id                 category_id,
c.name               category_name,
c.application_user   application_user,
c.base_cat_id        parent_category_id,
c.display_sequence   display_sequence
from wwv_flow_worksheet_categories c,
     wwv_flow_worksheets ws,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = c.security_group_id and
      f.id = ws.flow_id and ws.id = c.worksheet_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_APPLICATION_PAGE_IR_CAT IS 'Report column category definitions for interactive report columns'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_CAT.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_CAT.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_CAT.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_CAT.INTERACTIVE_REPORT_ID IS 'ID of the interactive report'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_CAT.CATEGORY_ID IS 'ID of the category'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_CAT.CATEGORY_NAME IS 'The name of the column category'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_CAT.PARENT_CATEGORY_ID IS 'The id of the parent category'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_CAT.DISPLAY_SEQUENCE IS 'The order the category will appear in a list'
/
