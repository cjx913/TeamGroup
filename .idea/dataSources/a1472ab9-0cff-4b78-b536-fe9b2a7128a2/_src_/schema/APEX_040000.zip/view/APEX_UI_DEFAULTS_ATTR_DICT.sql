CREATE VIEW APEX_UI_DEFAULTS_ATTR_DICT AS select
    w.short_name workspace,
    --
    syn.syn_name column_name,
    case when c.column_name != syn.syn_name
         then c.column_name
         end synonym_of,
    c.label,
    c.help_text,
    c.format_mask,
    c.default_value,
    c.form_format_mask,
    c.form_display_width,
    c.form_display_height,
    c.form_data_type,
    c.report_format_mask,
    c.report_col_alignment,
    c.created_by,
    c.created_on,
    c.last_updated_by,
    c.last_updated_on
from wwv_flow_hnt_column_dict c,
     wwv_flow_hnt_col_dict_syn syn,
     wwv_flow_company_schemas s,
     wwv_flow_companies w,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      c.security_group_id = w.PROVISIONING_COMPANY_ID and
      c.column_id = syn.column_id and
      syn.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      d.sgid != 0 and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_UI_DEFAULTS_ATTR_DICT IS 'The Attribute Dictionary is specific to a workspace.  It is part of User Interface Defaults and can be used in report and form creation.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.COLUMN_NAME IS 'Name of column or synonym.  Used to match against columns when UI Defaults are used by create wizards.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.SYNONYM_OF IS 'If a synonym, the name of the base column that it is a synonym of.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.LABEL IS 'Used for item label and report column heading.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.HELP_TEXT IS 'Used for help text for items and interactive report columns.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.FORMAT_MASK IS 'Used as the format mask for items and report columns.  Can be overwritten by report for form specific format masks.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.DEFAULT_VALUE IS 'Used as the default value for items.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.FORM_FORMAT_MASK IS 'If provided, used as the format mask for items, overriding any value for the general format mask.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.FORM_DISPLAY_WIDTH IS 'Used as the width of any items using this Attribute Definition.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.FORM_DISPLAY_HEIGHT IS 'Used as the height of any items using this Attribute Definition (only used by item types such as textares and shuttles).'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.FORM_DATA_TYPE IS 'Used as the data type for items (specifies whether this item contains VARCHAR or NUMBER data which results in an automatic validation).'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.REPORT_FORMAT_MASK IS 'If provided, used as the format mask for report columns, overriding any value for the general format mask.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.REPORT_COL_ALIGNMENT IS 'Used as the alignment for report column data (e.g. number are usually right justified).'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.CREATED_BY IS 'User that created this column.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.CREATED_ON IS 'Date this column was created.'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_UI_DEFAULTS_ATTR_DICT.LAST_UPDATED_ON IS 'Date of last update'
/
