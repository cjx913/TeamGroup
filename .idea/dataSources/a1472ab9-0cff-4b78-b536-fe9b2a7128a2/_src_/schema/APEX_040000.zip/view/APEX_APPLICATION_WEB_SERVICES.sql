CREATE VIEW APEX_APPLICATION_WEB_SERVICES AS select
    ws.short_name                          workspace,
    f.ID                                   application_id,
    f.NAME                                 application_name,
    --
    w.NAME                                 web_service_name,
    w.URL                                  ,
    w.ACTION                               ,
    w.PROXY_OVERRIDE                       ,
    w.soap_version                         ,
    w.SOAP_ENVELOPE                        ,
    w.FLOW_ITEMS_COMMA_DELIMITED           ,
    w.STATIC_PARM_01                       ,
    w.STATIC_PARM_02                       ,
    w.STATIC_PARM_03                       ,
    w.STATIC_PARM_04                       ,
    w.STATIC_PARM_05                       ,
    w.STATIC_PARM_06                       ,
    w.STATIC_PARM_07                       ,
    w.STATIC_PARM_08                       ,
    w.STATIC_PARM_09                       ,
    w.STATIC_PARM_10                       ,
    w.STYLESHEET                           ,
    --
    decode(w.REFERENCE_ID,
        null,'No','Yes')                   is_subscribed,
    (select flow_id||'. '||name n
     from wwv_flow_shared_web_services
     where id = w.id)                      subscribed_from,
    --
    w.LAST_UPDATED_BY                      last_updated_by,
    w.LAST_UPDATED_ON                      last_updated_on,
    --
    w.id                                   web_service_id
from wwv_flow_shared_web_services w,
     wwv_flows f,
     wwv_flow_companies ws,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = ws.PROVISIONING_COMPANY_ID and
      s.security_group_id = ws.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = w.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      ws.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_040000') or ws.PROVISIONING_COMPANY_ID != 10)
/
COMMENT ON VIEW APEX_APPLICATION_WEB_SERVICES IS 'Web Services referenceable from this Application'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.WEB_SERVICE_NAME IS 'Identifies the name of the Web Service'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.URL IS 'Specifies the URL used to post the SOAP request over HTTP'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.ACTION IS 'Indicates the intent of the SOAP HTTP request'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.PROXY_OVERRIDE IS 'Overrides the system defined HTTP proxy for request'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.SOAP_VERSION IS 'Identifies the SOAP version of the service, 1.1 or 1.2'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.SOAP_ENVELOPE IS 'Specifies the SOAP envelope to be used for the SOAP request to the Web service'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.FLOW_ITEMS_COMMA_DELIMITED IS 'Comma delimited list of application items'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_01 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_02 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_03 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_04 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_05 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_06 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_07 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_08 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_09 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STATIC_PARM_10 IS 'Identifies static parameters'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.STYLESHEET IS 'Stylesheet will be used to apply an XML transformation against the result of the SOAP Request'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.IS_SUBSCRIBED IS 'Identifies if this Web Service is subscribed from another Web Service'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.SUBSCRIBED_FROM IS 'Identifies the master component from which this component is subscribed'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.LAST_UPDATED_ON IS 'Date of last update'
/
COMMENT ON COLUMN APEX_APPLICATION_WEB_SERVICES.WEB_SERVICE_ID IS 'Identifies the primary key of the Web Service'
/
