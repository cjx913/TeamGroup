CREATE VIEW APEX_APPL_PLUGINS AS select p.id                        as plugin_id,
       f.workspace,
       f.application_id,
       f.application_name,
       case p.plugin_type
         when 'ITEM TYPE'          then 'Item Type'
         when 'DYNAMIC ACTION'     then 'Dynamic Action'
         when 'REGION TYPE'        then 'Region Type'
         when 'REPORT COLUMN TYPE' then 'Report Column Type'
         when 'VALIDATION TYPE'    then 'Validation Type'
         when 'PROCESS TYPE'       then 'Process Type'
         else                       p.plugin_type
       end                         as plugin_type,
       p.name,
       p.display_name,
       p.category,
       p.image_prefix              as file_prefix,
       p.plsql_code,
       p.render_function,
       p.ajax_function,
       p.validation_function,
       p.execution_function,
       p.builder_validation_function,
       p.migration_function,
       p.standard_attributes,
       p.sql_min_column_count,
       p.sql_max_column_count,
       p.sql_examples,
       p.attribute_01,
       p.attribute_02,
       p.attribute_03,
       p.attribute_04,
       p.attribute_05,
       p.attribute_06,
       p.attribute_07,
       p.attribute_08,
       p.attribute_09,
       p.attribute_10,
       nvl2(p.reference_id, 'Yes', 'No') as is_subscribed,
       ( select s.flow_id||'. '||s.display_name
           from wwv_flow_plugins s
          where s.id = p.reference_id )  as subscribed_from,
       p.reference_id                    as subscribed_from_id,
       p.help_text,
       p.version_identifier,
       p.about_url,
       p.plugin_comment                  as component_comment,
       p.created_by,
       p.created_on,
       p.last_updated_by,
       p.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_plugins p
 where p.flow_id = f.application_id
/
COMMENT ON VIEW APEX_APPL_PLUGINS IS 'Stores the meta data for the plug-ins of an application.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.PLUGIN_ID IS 'Identifies the primary key of this component'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.PLUGIN_TYPE IS 'Type of the plug-in.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.NAME IS 'Internal name of the plug-in which is used to reference it for example in apex_application_page_items.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.DISPLAY_NAME IS 'Contains the name of the plug-in which is displayed on the UI.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.CATEGORY IS 'Category under which the plug-in should displayed on the UI.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.FILE_PREFIX IS 'File prefix which is used by the plug-in to load additional files like CSS, Javascript and images.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.PLSQL_CODE IS 'PL/SQL code which contains the logic of the plug-in.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.RENDER_FUNCTION IS 'During rendering of the page this function is called to render the plug-in.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.AJAX_FUNCTION IS 'Function which is called for a plug-in when there is an incoming AJAX call from the browser.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.VALIDATION_FUNCTION IS 'Function which is called to validate the plug-ins data before the defined validations are fired.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.EXECUTION_FUNCTION IS 'Function which is called for plug-ins that are just used on the server side.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.BUILDER_VALIDATION_FUNCTION IS 'Function which is called to validate the entered attribute values in the builder.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.MIGRATION_FUNCTION IS 'Function which is called when a new version of a plug-in is installed to migrate existing attribute values.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.STANDARD_ATTRIBUTES IS 'Contains the APEX provided standard attributes which should be displayed for the plug-in.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.SQL_MIN_COLUMN_COUNT IS 'Minimum number of columns the SQL query of the LOV or region source has to have.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.SQL_MAX_COLUMN_COUNT IS 'Maximum number of columns the SQL query of the LOV or region source can have.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.SQL_EXAMPLES IS 'LOV or region source SQL examples which are displayed for the plug-in in the Builder.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_01 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_02 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_03 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_04 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_05 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_06 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_07 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_08 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_09 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ATTRIBUTE_10 IS 'Dynamic attribute to store additional data'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.IS_SUBSCRIBED IS 'Identifies if this plug-in is subscribed from another plug-in'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.SUBSCRIBED_FROM IS 'Identifies the master component from which this component is subscribed'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.SUBSCRIBED_FROM_ID IS 'Id the master component from which this component is subscribed'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.HELP_TEXT IS 'Help text which is displayed for the plug-in in the Builder.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.VERSION_IDENTIFIER IS 'Version identifier of the plug-in.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.ABOUT_URL IS 'URL to get additional information about the plug-in.'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.COMPONENT_COMMENT IS 'Developer Comment'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.CREATED_BY IS 'APEX developer who created the plug-in'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.CREATED_ON IS 'Date of creation'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_APPL_PLUGINS.LAST_UPDATED_ON IS 'Date of last update'
/
