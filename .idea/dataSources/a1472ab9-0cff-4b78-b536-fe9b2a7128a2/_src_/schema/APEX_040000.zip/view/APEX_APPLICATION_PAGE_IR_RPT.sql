CREATE VIEW APEX_APPLICATION_PAGE_IR_RPT AS select
w.short_name                 workspace,
f.id                         application_id,
f.name                       application_name,
r.page_id                    page_id,
r.worksheet_id               interactive_report_id,
r.id                         report_id,
r.application_user           application_user,
r.name                       report_name,
r.report_alias               ,
r.session_id                 ,
r.base_report_id             ,
r.description                report_description,
r.report_seq                 display_sequence,
(case when r.report_type = 'APX_WS_DATA' then 'WEBSHEET_DATA_SECTION'
 else r.report_type end)     report_view_mode,
r.status                     ,
r.category_id                ,
(case when r.is_default = 'Y' and r.application_user='APXWS_DEFAULT' then 'PRIMARY_DEFAULT'
      when r.is_default = 'Y' and r.application_user='APXWS_ALTERNATIVE' then 'ALTERNATIVE_DEFAULT'
      when r.session_id is null and r.status='PUBLIC' then 'PUBLIC'
      when r.session_id is null and r.status='PRIVATE' and nvl(r.report_type,'REPORT') not in ('NOTIFICATION','APX_WS_DATA') then 'PRIVATE'
      When r.session_id is null and r.status='PRIVATE' and nvl(r.report_type,'REPORT')='NOTIFICATION' then 'PRIVATE_NOTIFICATION'
      when r.session_id is null and r.status='PRIVATE' and nvl(r.report_type,'REPORT')='APX_WS_DATA' then 'WEBSHEET_DATA_SECTION'
 else 'SESSION' end)         report_type,
--
(case when r.report_alias is not null then
     (select 'f?p='||f.id||':'||r.page_id||':&APP_SESSION.:IR_REPORT_'||r.report_alias from dual)
 end)                        report_link_example,
r.display_rows               ,
r.report_columns             ,
--
r.sort_column_1              ,
r.sort_direction_1           ,
r.sort_column_2              ,
r.sort_direction_2           ,
r.sort_column_3              ,
r.sort_direction_3           ,
r.sort_column_4              ,
r.sort_direction_4           ,
r.sort_column_5              ,
r.sort_direction_5           ,
r.sort_column_6              ,
r.sort_direction_6           ,
--
r.break_on                   ,
r.break_enabled_on           ,
--
r.sum_columns_on_break       ,
r.avg_columns_on_break       ,
r.max_columns_on_break       ,
r.min_columns_on_break       ,
r.median_columns_on_break    ,
r.count_columns_on_break     ,
r.count_distnt_col_on_break  ,
--
r.flashback_mins_ago         flashback_minutes,
decode(r.flashback_enabled,'Y','Yes','N','No',r.flashback_enabled) flashback_enabled,
--
r.chart_type                 ,
r.chart_label_column         ,
r.chart_label_title          ,
r.chart_value_column         ,
r.chart_aggregate            ,
r.chart_value_title          ,
decode(r.chart_sorting,
       'DEFAULT','Default',
       'VALUE_DESC','Value - Descending',
       'VALUE_ASC','Value - Ascending',
       'LABEL_DESC','Label - Descending',
       'LAVEL_ASC','Label - Ascending',
       r.chart_sorting)  chart_sort_order,
--
r.created_on        ,
r.created_by        ,
r.updated_on        last_updated_on,
r.updated_by        last_updated_by
--
from wwv_flow_worksheet_rpts r,
     wwv_flow_worksheets ws,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = r.security_group_id and
      f.id = ws.flow_id and ws.id = r.worksheet_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_APPLICATION_PAGE_IR_RPT IS 'Identifies user-level report settings for an interactive report'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.PAGE_ID IS 'Identifies page number'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.INTERACTIVE_REPORT_ID IS 'ID of the interactive report'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.REPORT_ID IS 'ID of the report'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.APPLICATION_USER IS 'The user these report settings are used by'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.REPORT_NAME IS 'The name of these report settings'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.REPORT_ALIAS IS 'An alternate alphanumeric report identifier to use in report link'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SESSION_ID IS 'For session-level report settings, the session ID associated with this record'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.BASE_REPORT_ID IS 'For session-level report settings, the base report settings this record was derived from'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.REPORT_DESCRIPTION IS 'The description given to the report'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.DISPLAY_SEQUENCE IS 'The order the report will appear in a list'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.REPORT_VIEW_MODE IS 'Identifies the current view settings of the report'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.STATUS IS 'The shared status of these settings'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CATEGORY_ID IS 'The category_id of the report'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.REPORT_TYPE IS 'Identifies whether this is a PRIMARY_DEFAULT,ALTERNATIVE_DEFAULT,PUBLIC,PRIVATE,PRIVATE_NOTIFICATION,WEBSHEET_DATA_SECTION, or SESSION based set of report settings'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.REPORT_LINK_EXAMPLE IS 'An example to link to specific saved reports'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.DISPLAY_ROWS IS 'Number of rows to display in the report'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.REPORT_COLUMNS IS 'List of columns to display in the report'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_1 IS 'First column to sort by'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_1 IS 'Direction to use for first column sort'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_2 IS 'First column to sort by'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_2 IS 'Direction to use for first column sort'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_3 IS 'Second column to sort by'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_3 IS 'Direction to use for first column sort'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_4 IS 'Third column to sort by'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_4 IS 'Direction to use for first column sort'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_5 IS 'Fourth column to sort by'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_5 IS 'Direction to use for first column sort'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_6 IS 'Fifth column to sort by'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_6 IS 'Direction to use for first column sort'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.BREAK_ON IS 'Identifies a set of columns to break on'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.BREAK_ENABLED_ON IS 'Identifies which control breaks are enabled'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.SUM_COLUMNS_ON_BREAK IS 'Identifies which columns to aggregate with a sum'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.AVG_COLUMNS_ON_BREAK IS 'Identifies which columns to aggregate with a avg'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.MAX_COLUMNS_ON_BREAK IS 'Identifies which columns to aggregate with a max'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.MIN_COLUMNS_ON_BREAK IS 'Identifies which columns to aggregate with a min'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.MEDIAN_COLUMNS_ON_BREAK IS 'Identifies which columns to aggregate with a median'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.COUNT_COLUMNS_ON_BREAK IS 'Identifies which columns to aggregate with a count'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.COUNT_DISTNT_COL_ON_BREAK IS 'Identifies which columns to aggregate with a count distinct'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.FLASHBACK_MINUTES IS 'Identifies the number of minutes to flashback in the query'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.FLASHBACK_ENABLED IS 'Identifies whether flashback is enabled'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CHART_TYPE IS 'Identifies the current chart type'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CHART_LABEL_COLUMN IS 'Identifies the alias of the column to use as labels in a chart'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CHART_LABEL_TITLE IS 'Text to use as the label axis title for a chart'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CHART_VALUE_COLUMN IS 'Identifies the alias of the column to use as values in a chart'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CHART_AGGREGATE IS 'Identifies an aggregation function to use on the values in the chart'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CHART_VALUE_TITLE IS 'Text to use as the value axis title for a chart'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CHART_SORT_ORDER IS 'Identifies the current chart sorting method'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CREATED_ON IS 'Auditing; date the record was created.'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.CREATED_BY IS 'Auditing; user that created the record.'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.LAST_UPDATED_ON IS 'Auditing; date the record was last modified.'
/
COMMENT ON COLUMN APEX_APPLICATION_PAGE_IR_RPT.LAST_UPDATED_BY IS 'Auditing; user that last modified the record.'
/
