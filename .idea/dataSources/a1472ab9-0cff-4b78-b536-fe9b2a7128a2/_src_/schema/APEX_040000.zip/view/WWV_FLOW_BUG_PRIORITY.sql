CREATE VIEW WWV_FLOW_BUG_PRIORITY AS select 1 id, wwv_flow_lang.system_message('ASAP') the_name from dual union all
select 2 id, wwv_flow_lang.system_message('BY_NEXT_PATCH') the_name from dual union all
select 3 id, wwv_flow_lang.system_message('BY_NEXT_RELEASE') the_name from dual union all
select 4 id, wwv_flow_lang.system_message('NOT_PRORITIZED') the_name from dual
/
