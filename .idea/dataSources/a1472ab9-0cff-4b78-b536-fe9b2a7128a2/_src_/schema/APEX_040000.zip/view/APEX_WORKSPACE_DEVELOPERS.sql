CREATE VIEW APEX_WORKSPACE_DEVELOPERS AS select "WORKSPACE_ID","WORKSPACE_NAME","FIRST_SCHEMA_PROVISIONED","USER_NAME","EMAIL","DATE_CREATED","DATE_LAST_UPDATED","AVAILABLE_SCHEMAS","IS_ADMIN","IS_APPLICATION_DEVELOPER"
from apex_workspace_apex_users
where is_application_developer = 'Yes'
/
COMMENT ON VIEW APEX_WORKSPACE_DEVELOPERS IS 'Application Express (APEX) developers, APEX users with privilege to develop applications'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.WORKSPACE_ID IS 'Primary key that identifies the workspace'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.WORKSPACE_NAME IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.FIRST_SCHEMA_PROVISIONED IS 'The associated database schema identified when this workspace was created'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.USER_NAME IS 'The APEX user name used to authenticate to an APEX web page or APEX application'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.EMAIL IS 'The email associated with this APEX user'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.DATE_CREATED IS 'The date the APEX user was created'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.DATE_LAST_UPDATED IS 'The date the APEX user definition was last updated'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.AVAILABLE_SCHEMAS IS 'The number of database schemas available to the workspace developer'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.IS_ADMIN IS 'Identifies if the APEX user has APEX workspace administration privilege'
/
COMMENT ON COLUMN APEX_WORKSPACE_DEVELOPERS.IS_APPLICATION_DEVELOPER IS 'Identifies if the APEX user has APEX application development privilege'
/
