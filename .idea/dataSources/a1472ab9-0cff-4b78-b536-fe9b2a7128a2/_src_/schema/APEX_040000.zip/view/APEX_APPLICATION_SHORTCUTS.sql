CREATE VIEW APEX_APPLICATION_SHORTCUTS AS select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    s.SHORTCUT_NAME                  shortcut_name,
    --s.SHORTCUT_CONSIDERATION_SEQ     consideration_sequence,
    s.SHORTCUT_TYPE                  shortcut_type,
    nvl((select r from apex_standard_conditions where d = s.SHORTCUT_CONDITION_TYPE1),s.SHORTCUT_CONDITION_TYPE1)
                                     condition_type,
    s.SHORTCUT_CONDITION1            condition_expression1,
    --s.SHORTCUT_CONDITION_TYPE2       ,
    s.SHORTCUT_CONDITION2            condition_expression2,
    s.ERROR_TEXT                     error_text,
    (select case when s.build_option > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(s.BUILD_OPTION))      build_option,
    s.SHORTCUT                       shortcut,
    --
    decode(s.REFERENCE_ID,
    null,'No','Yes')                 is_subscribed,
    (select flow_id||'. '||name n
     from wwv_flow_shortcuts
     where id = s.reference_id)      subscribed_from,
    --
    s.LAST_UPDATED_BY                last_updated_by,
    s.LAST_UPDATED_ON                last_updated_on,
    s.COMMENTS                       component_comments,
    s.id                             shortcut_id,
    --
    s.SHORTCUT_NAME
    ||' '||s.SHORTCUT_TYPE
    ||' cond='||s.SHORTCUT_CONDITION_TYPE1
    ||substr(s.SHORTCUT_CONDITION1,1,30)||length(s.shortcut_condition1)||'.'
    ||substr(s.SHORTCUT_CONDITION2,1,30)||length(s.shortcut_condition2)
    ||' e='||substr(s.ERROR_TEXT,1,30)||length(s.ERROR_TEXT)
    ||' bo='||(select PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(s.BUILD_OPTION))
    ||' s='||dbms_lob.substr(s.SHORTCUT,50,1)||dbms_lob.getlength(s.SHORTCUT)
    ||' r='||decode(s.REFERENCE_ID,null,'No','Yes')
    component_signature
from wwv_flow_shortcuts s,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas ws,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (ws.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = ws.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      ws.security_group_id = w.PROVISIONING_COMPANY_ID and
      ws.schema = f.owner and
      f.id = s.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_APPLICATION_SHORTCUTS IS 'Identifies Application Shortcuts which can be referenced "MY_SHORTCUT" syntax'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.SHORTCUT_NAME IS 'Identifies the Shortcut Name, which can be referenced using "SHORTCUT_NAME" syntax'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.SHORTCUT_TYPE IS 'The shortcut type identifies how the Shortcut text is to be interpreted; for example it could by PL/SQL or HTML.'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.CONDITION_TYPE IS 'Identifies the condition type used to conditionally execute the shortcut'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.CONDITION_EXPRESSION1 IS 'Specifies an expression based on the specific condition type selected.'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.CONDITION_EXPRESSION2 IS 'Specifies an expression based on the specific condition type selected.'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.ERROR_TEXT IS 'Text to be displayed if this shortcut raises an exception'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.BUILD_OPTION IS 'Shortcut will be available if the Build Option is enabled'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.SHORTCUT IS 'Text and definition of this Shortcut'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.IS_SUBSCRIBED IS 'Identifies if this Shortcut is subscribed from another Shortcut'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.SUBSCRIBED_FROM IS 'Identifies the master component from which this component is subscribed'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.LAST_UPDATED_ON IS 'Date of last update'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.COMPONENT_COMMENTS IS 'Developer comments'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.SHORTCUT_ID IS 'Primary Key of this Shortcut'
/
COMMENT ON COLUMN APEX_APPLICATION_SHORTCUTS.COMPONENT_SIGNATURE IS 'Identifies attributes defined at a given component level to facilitate application comparisons'
/
