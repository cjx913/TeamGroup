CREATE VIEW APEX_APPLICATION_TRANS_MAP AS select f.workspace                      workspace,
       m.ID                             map_id,
       m.primary_language_flow_id       primary_application_id,
       f.application_name               primary_application_name,
       m.translation_flow_id            translated_application_id,
       m.translation_flow_language_code translated_app_language,
       m.translation_image_directory    translated_appl_img_dir,
       m.translation_comments           translation_comments,
       m.map_comments                   translation_map_comments,
       m.last_updated_by,
       m.last_updated_on,
       m.created_by,
       m.created_on
  from wwv_flow_authorized f,
       wwv_flow_language_map m
 where m.primary_language_flow_id = f.application_id
/
COMMENT ON VIEW APEX_APPLICATION_TRANS_MAP IS 'Application Groups defined per workspace.  Applications can be associated with an application group.'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.MAP_ID IS 'Unique ID that identifies this translation mapping'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.PRIMARY_APPLICATION_ID IS 'Unique ID of the application that is the target of the translation'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.PRIMARY_APPLICATION_NAME IS 'Name of the application that is the target of the translation'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.TRANSLATED_APPLICATION_ID IS 'Unique ID of the translated application'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.TRANSLATED_APP_LANGUAGE IS 'Language code, for example "fr" or "pt-br"'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.TRANSLATED_APPL_IMG_DIR IS 'Optional directory of translated images'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.TRANSLATION_COMMENTS IS 'Comments associated with this translation'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.TRANSLATION_MAP_COMMENTS IS 'Comments associated with this mapping'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.LAST_UPDATED_BY IS 'Last user to update this translation mapping'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.LAST_UPDATED_ON IS 'Date of last update to this translation mapping'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.CREATED_BY IS 'User that created this translation mapping'
/
COMMENT ON COLUMN APEX_APPLICATION_TRANS_MAP.CREATED_ON IS 'Date this translation mapping was created'
/
