CREATE VIEW WWV_FLOW_FEATURE_GLOBSTAT AS select 0 id, wwv_flow_lang.system_message('NO_STATUS')           the_name from dual union all
select 1 id, wwv_flow_lang.system_message('NEEDS_REVIEW')        the_name from dual union all
select 2 id, wwv_flow_lang.system_message('REVIEWING')           the_name from dual union all
select 3 id, wwv_flow_lang.system_message('PROBLEMS_IDENTIFIED') the_name from dual union all
select 4 id, wwv_flow_lang.system_message('PROBLEMS_CORRECTED')  the_name from dual union all
select 5 id, wwv_flow_lang.system_message('COMPLETE_NO_ISSUES') the_name from dual
/
