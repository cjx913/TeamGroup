CREATE VIEW APEX_APPL_PLUGIN_ATTR_VALUES AS select v.id                 as plugin_attribute_value_id,
       f.workspace,
       f.application_id,
       f.application_name,
       v.plugin_attribute_id,
       a.prompt             as plugin_attribute_prompt,
       v.display_sequence,
       v.display_value,
       v.return_value,
       v.created_by,
       v.created_on,
       v.last_updated_by,
       v.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_plugin_attr_values v,
       wwv_flow_plugin_attributes a
 where v.flow_id = f.application_id
   and a.id      = v.plugin_attribute_id
/
COMMENT ON VIEW APEX_APPL_PLUGIN_ATTR_VALUES IS 'Stores the possible values of a plug-in attribute if it''s of type selectlist.'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.PLUGIN_ATTRIBUTE_VALUE_ID IS 'Identifies the primary key of this component'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.PLUGIN_ATTRIBUTE_ID IS 'Id of the attribute this value is part of'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.PLUGIN_ATTRIBUTE_PROMPT IS 'Label of the attribute this value is part of'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.DISPLAY_SEQUENCE IS 'Order sequence in which the values are displayed.'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.DISPLAY_VALUE IS 'Value displayed to end users'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.RETURN_VALUE IS 'Value stored in attribute_xx column.'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.CREATED_BY IS 'APEX developer who created the plugin attribute value'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.CREATED_ON IS 'Date of creation'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_APPL_PLUGIN_ATTR_VALUES.LAST_UPDATED_ON IS 'Date of last update'
/
