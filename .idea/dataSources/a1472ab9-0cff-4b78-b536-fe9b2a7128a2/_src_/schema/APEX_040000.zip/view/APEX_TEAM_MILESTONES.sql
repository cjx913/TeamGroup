CREATE VIEW APEX_TEAM_MILESTONES AS select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
	m.ID                        milestone_id,
	m.EVENT_NAME                milestone,
	m.EVENT_OWNER               milestone_owner,
	m.EVENT_DATE                milestone_date,
	m.EVENT_TYPE                milestone_type,
	m.RELEASE                   release,
	m.EVENT_DESC                milestone_description,
	m.TAGS                      tags,
	--
	m.CREATED_BY,
	m.CREATED_ON,
	m.UPDATED_BY,
	m.UPDATED_ON,
	m.EVENT_ID                  friendly_milestone_id,
	m.SELECTABLE_FROM_FEATURES_YN
from
    WWV_FLOW_EVENTS m,
    wwv_flow_companies w
where
    m.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/
COMMENT ON VIEW APEX_TEAM_MILESTONES IS 'Identifies bugs, also known as software defects.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.WORKSPACE_ID IS 'Primary key that identifies the workspace.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.WORKSPACE_NAME IS 'Name of the workspace.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.MILESTONE_ID IS 'Primary key of the bug.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.MILESTONE IS 'Name of the milestone.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.MILESTONE_OWNER IS 'Owner of the milestone.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.MILESTONE_DATE IS 'Date on which the milestone is to occur.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.MILESTONE_TYPE IS 'Type of milestone.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.RELEASE IS 'Release milestone is associated with.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.MILESTONE_DESCRIPTION IS 'Description of milestone.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.TAGS IS 'Tags associated with this milestone.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.CREATED_BY IS 'Developer who created this milestone.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.CREATED_ON IS 'Date on which this milestone was created.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.UPDATED_BY IS 'Developer who last updated this milestone.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.UPDATED_ON IS 'Date on which this milestone was last updated.'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.FRIENDLY_MILESTONE_ID IS 'More readable id for the milestone (unique within workspace only).'
/
COMMENT ON COLUMN APEX_TEAM_MILESTONES.SELECTABLE_FROM_FEATURES_YN IS 'Identifies whether or not this milestone can be associated with a feature.'
/
