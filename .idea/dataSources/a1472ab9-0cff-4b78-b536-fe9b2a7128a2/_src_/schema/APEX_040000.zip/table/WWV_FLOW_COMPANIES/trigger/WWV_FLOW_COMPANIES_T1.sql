CREATE TRIGGER WWV_FLOW_COMPANIES_T1
BEFORE INSERT OR UPDATE
  ON WWV_FLOW_COMPANIES
FOR EACH ROW
  begin
    if :new.provisioning_company_id = 20 and :new.short_name not in ('ORACLE','COM.ORACLE.APEX.APPLICATIONS') then
        raise_application_error(-20001,wwv_flow_lang.system_message('TRIGGER.SGID_RESERVED'));
    end if;
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    if :new.allow_to_be_purged_yn is null then
        :new.allow_to_be_purged_yn := 'Y';
    end if;
    :new.short_name := upper(:new.short_name);
end;
/
