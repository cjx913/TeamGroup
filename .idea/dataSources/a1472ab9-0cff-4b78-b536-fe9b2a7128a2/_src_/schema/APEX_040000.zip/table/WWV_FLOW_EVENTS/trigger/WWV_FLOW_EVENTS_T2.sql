CREATE TRIGGER WWV_FLOW_EVENTS_T2
AFTER DELETE
  ON WWV_FLOW_EVENTS
FOR EACH ROW
  begin
    if wwv_flow.g_workspace_delete_in_progress = FALSE then
	      delete from wwv_flow_team_tags where component_id = :old.id;
	  end if;
end wwv_flow_events_t2;
/
