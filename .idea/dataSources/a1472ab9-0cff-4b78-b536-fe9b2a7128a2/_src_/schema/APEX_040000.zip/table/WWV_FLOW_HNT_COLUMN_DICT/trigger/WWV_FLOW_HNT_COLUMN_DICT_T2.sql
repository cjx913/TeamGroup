CREATE TRIGGER WWV_FLOW_HNT_COLUMN_DICT_T2
AFTER INSERT
  ON WWV_FLOW_HNT_COLUMN_DICT
FOR EACH ROW
  begin
    if not wwv_flow.g_import_in_progress then
        insert into wwv_flow_hnt_col_dict_syn
           (column_id, syn_name)
        values
           (:new.column_id, :new.column_name);
    end if;
end;
/
