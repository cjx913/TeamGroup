CREATE TRIGGER WWV_FLOW_LOCK_PAGE_LOG_T1
BEFORE INSERT OR UPDATE
  ON WWV_FLOW_LOCK_PAGE_LOG
FOR EACH ROW
  begin
    --
    -- ID
    --
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    --
    -- last updated
    --
    if not wwv_flow.g_import_in_progress then
        :new.action_date := sysdate;
    end if;
end;
/
