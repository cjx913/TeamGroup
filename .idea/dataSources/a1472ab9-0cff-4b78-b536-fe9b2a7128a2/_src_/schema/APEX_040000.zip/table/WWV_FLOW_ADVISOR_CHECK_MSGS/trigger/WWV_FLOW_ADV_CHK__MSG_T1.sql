CREATE TRIGGER WWV_FLOW_ADV_CHK__MSG_T1
BEFORE INSERT OR UPDATE
  ON WWV_FLOW_ADVISOR_CHECK_MSGS
FOR EACH ROW
  begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
end;
/
