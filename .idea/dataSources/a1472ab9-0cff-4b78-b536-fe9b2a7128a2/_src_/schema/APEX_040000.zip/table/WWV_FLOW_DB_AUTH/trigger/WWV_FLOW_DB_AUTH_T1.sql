CREATE TRIGGER WWV_FLOW_DB_AUTH_T1
BEFORE INSERT OR UPDATE
  ON WWV_FLOW_DB_AUTH
FOR EACH ROW
  begin
    :new.db_auth_schema := upper(:new.db_auth_schema);
end;
/
