CREATE TRIGGER WWV_FLOW_VERSION_T1
BEFORE INSERT
  ON WWV_FLOW_VERSION$
FOR EACH ROW
  begin
    select wwv_flow_version_seq.nextval,sysdate into :new.seq,:new.date_applied from dual;
end;
/
