CREATE TRIGGER WWV_FLOW_SESSIONS_T2
BEFORE DELETE
  ON WWV_FLOW_SESSIONS$
FOR EACH ROW
  begin
   delete from wwv_flow_debug where id = :old.id;
   delete from wwv_flow_worksheet_rpts where session_id = :old.id;
   --
   update wwv_flow_companies
   set last_login = trunc(:old.CREATED_ON)
   where provisioning_company_id = :old.security_group_id and
        (last_login < trunc(:old.CREATED_ON) or last_login is null);
end;
/
