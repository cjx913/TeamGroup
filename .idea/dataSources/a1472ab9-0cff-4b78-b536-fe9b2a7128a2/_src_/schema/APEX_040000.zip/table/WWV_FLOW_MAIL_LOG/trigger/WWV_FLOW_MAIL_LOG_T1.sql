CREATE TRIGGER WWV_FLOW_MAIL_LOG_T1
BEFORE INSERT
  ON WWV_FLOW_MAIL_LOG
FOR EACH ROW
  begin
    :new.last_updated_on := sysdate;
end;
/
