CREATE TRIGGER WWV_FLOW_WORKSHEETS_T2
BEFORE DELETE
  ON WWV_FLOW_WORKSHEETS
  begin
    wwv_flow_worksheet.g_delete_in_progress := true;
end;
/
