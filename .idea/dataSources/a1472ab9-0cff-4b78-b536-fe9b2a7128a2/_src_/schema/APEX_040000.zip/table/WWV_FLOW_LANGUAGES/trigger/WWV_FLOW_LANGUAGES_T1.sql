CREATE TRIGGER WWV_FLOW_LANGUAGES_T1
BEFORE INSERT OR UPDATE
  ON WWV_FLOW_LANGUAGES
FOR EACH ROW
  begin
    :new.lang_id_upper := upper(:new.lang_id);
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
end;
/
