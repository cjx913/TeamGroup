CREATE VIEW V_$MYSTAT AS select "SID","STATISTIC#","VALUE" from v$mystat
/
