CREATE VIEW GV_$MYSTAT AS select "INST_ID","SID","STATISTIC#","VALUE" from gv$mystat
/
