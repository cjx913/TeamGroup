CREATE VIEW V_$BACKUP_DEVICE AS select "DEVICE_TYPE","DEVICE_NAME" from v$backup_device
/
