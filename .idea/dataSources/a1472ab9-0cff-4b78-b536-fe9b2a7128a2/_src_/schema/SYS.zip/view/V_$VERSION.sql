CREATE VIEW V_$VERSION AS select "BANNER" from v$version
/
