CREATE VIEW V_$BACKUP AS select "FILE#","STATUS","CHANGE#","TIME" from v$backup
/
