CREATE VIEW V_$QUEUEING_MTH AS select "NAME" from v$queueing_mth
/
