CREATE VIEW V_$DBFILE AS select "FILE#","NAME" from v$dbfile
/
