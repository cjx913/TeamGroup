CREATE VIEW GV_$DB_PIPES AS select "INST_ID","OWNERID","NAME","TYPE","PIPE_SIZE" from gv$db_pipes
/
