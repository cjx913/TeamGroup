CREATE VIEW V_$PGASTAT AS select "NAME","VALUE","UNIT" from v$pgastat
/
