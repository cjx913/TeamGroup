CREATE VIEW V_$FAST_START_SERVERS AS select "STATE","UNDOBLOCKSDONE","PID","XID" from v$fast_start_servers
/
