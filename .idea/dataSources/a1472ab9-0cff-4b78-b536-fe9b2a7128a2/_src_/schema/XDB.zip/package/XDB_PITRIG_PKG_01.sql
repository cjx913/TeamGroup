CREATE package     XDB_PITRIG_PKG_01 authid definer AS
  procedure pitrig_del(owner varchar2, name varchar2, deloid raw, tbloid raw);
  procedure pitrig_upd(owner varchar2, name varchar2, deloid raw, tbloid raw,
                       cuser varchar2);
  procedure pitrig_delmetadata(owner varchar2, name varchar2, deloid raw,
                               tbloid raw, resid raw, cuser varchar2);
  procedure pitrig_updmetadata(owner varchar2, name varchar2, deloid raw,
                               tbloid raw, resid raw, cuser varchar2);
end XDB_PITRIG_PKG_01;
/
