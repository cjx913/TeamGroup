CREATE PACKAGE     dbms_xdb_admin AUTHID CURRENT_USER IS
--------
-- Procedure to create an XML Index on the repository
procedure CreateRepositoryXMLIndex;

-- Procedure to index resource at path 'path' or all resources in
-- the subtree rooted at 'path'.
procedure XMLIndexAddPath(path      IN VARCHAR2,
                          recurse   IN boolean := TRUE);

-- Procedure to remove resource at path 'path' from the Repository
-- XML Index or to remove all resources in the subtree rooted at
-- 'path' from the Repository XML Index.
procedure XMLIndexRemovePath(path        IN VARCHAR2,
                             recurse     IN boolean := TRUE);

-- Procedure to drop an XML Index on the repository
procedure DropRepositoryXMLIndex;

-- Procedure to unmark the indexed flags of the XML Index on the repository
procedure ClearRepositoryXMLIndex;

end dbms_xdb_admin;
/
