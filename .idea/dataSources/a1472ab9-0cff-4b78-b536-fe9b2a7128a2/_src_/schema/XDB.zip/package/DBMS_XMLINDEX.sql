CREATE PACKAGE     dbms_xmlindex AUTHID CURRENT_USER AS

----------------------------------------------------------------------------
-- PROCEDURE - CreateNumberIndex
--     Creates an index for number values in the XMLIndex. The index
--     is created on the VALUE column of the XMLIndex path table on the
--     expression TO_BINARY_DOUBLE(VALUE).
-- PARAMETERS -
--  xml_index_schema
--     Schema of the XMLIndex: default is current user schema
--  xml_index_name
--     Name of the XMLIndex
--  num_index_name: default is system-generated
--     Name of the number index to create
--  num_index_clause
--     Storage clause for the number index. This would simply be appended
--     to the CREATE INDEX statement.
--  xmltypename
--     Xml type name corresponding to the number - one of the following:
--     float
--     double
--     decimal
--     integer
--     nonPositiveInteger
--     negativeInteger
--     long
--     int
--     short
--     byte
--     nonNegativeInteger
--     unsignedLong
--     unsignedInt
--     unsignedShort
--     unsignedByte
--     positiveInteger
--  column_name
--     Name of the path table column on which to create the number index.
----------------------------------------------------------------------------
PROCEDURE CreateNumberIndex(xml_index_schema IN VARCHAR2 := USER,
                            xml_index_name   IN VARCHAR2,
                            num_index_name   IN VARCHAR2 := NULL,
                            num_index_clause IN VARCHAR2 := NULL,
                            xmltypename      IN VARCHAR2 := NULL,
                            column_name      IN VARCHAR2 := NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(CreateNumberIndex, UNSUPPORTED_WITH_COMMIT);

----------------------------------------------------------------------------
-- PROCEDURE - CreateDateIndex
--     Creates an index for date values in the XMLIndex. The user specifies
--     the XML type name (date, dateTime etc.) and the index is created
--     on SYS_XMLCONV(VALUE) which would always return a TIMESTAMP datatype.
-- PARAMETERS -
--  xml_index_schema
--     Schema of the XMLIndex: default is current user schema
--  xml_index_name
--     Name of the XMLIndex
--  date_index_name: default is system generated
--     Name of the date index to be created
--  xmltypename
--     XML type name - one of the following
--         dateTime
--         time
--         date
--         gDay
--         gMonth
--         gYear
--         gYearMonth
--         gMonthDay
--  date_index_clause
--     Storage clause for the date index. This would simply be appended
--     to the CREATE INDEX statement.
--  column_name
--     Name of the path table column on which to create the date index.
----------------------------------------------------------------------------
PROCEDURE CreateDateIndex(xml_index_schema  IN VARCHAR2 := USER,
                          xml_index_name    IN VARCHAR2,
                          date_index_name   IN VARCHAR2 := NULL,
                          xmltypename       IN VARCHAR2 := NULL,
                          date_index_clause IN VARCHAR2 := NULL,
                          column_name       IN VARCHAR2 := NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(CreateDateIndex, UNSUPPORTED_WITH_COMMIT);

----------------------------------------------------------------------------
--    PROCEDURE SyncIndex(xml_index_schema IN VARCHAR2,
--                        xml_index_name   IN VARCHAR2,
--                        partition_name   IN VARCHAR2,
--			  reindex          IN BOOLEAN);

--    This procedure synchronizes an asynchronously maintained xmlindex.
--    It applies to the xmlindex changes that are logged in the pending
--    table, and brings the path table up-to-date with the base xmltype
--    column.
--
--    PARAMETERS
--    (a) xml_index_schema - Name of the owner of the XMLIndex.
--    (b) xml_index_name   - Name of the XMLIndex.
--    (c) partition_name   - Optional name of the partition to be synced.
--    (d) reindex          - If true drops and recreates secondary indexes
--				on path table. Default is false.
----------------------------------------------------------------------------
PROCEDURE SyncIndex(xml_index_schema IN VARCHAR2 default USER,
                    xml_index_name   IN VARCHAR2,
                    partition_name   IN VARCHAR2 default NULL,
		    reindex          IN BOOLEAN  default FALSE);
PRAGMA SUPPLEMENTAL_LOG_DATA(SyncIndex, UNSUPPORTED_WITH_COMMIT);

PROCEDURE gather_table_stats(ownname          IN VARCHAR2,
                             tabname          IN VARCHAR2,
                             partname         IN VARCHAR2 default NULL,
                             estimate_percent IN NUMBER default 0,
                             block_sample     IN NUMBER default 0,
                             granularity      IN VARCHAR2 default 'AUTO');
PRAGMA SUPPLEMENTAL_LOG_DATA(gather_table_stats, MANUAL);

PROCEDURE delete_table_stats(ownname       IN VARCHAR2,
                             tabname       IN VARCHAR2,
                             partname      IN VARCHAR2 default NULL,
                             cascade_parts IN NUMBER default 1);
PRAGMA SUPPLEMENTAL_LOG_DATA(delete_table_stats, UNSUPPORTED_WITH_COMMIT);

PROCEDURE registerparameter(paramname       IN VARCHAR2,
                            paramstr        IN CLOB);
PRAGMA SUPPLEMENTAL_LOG_DATA(registerparameter, UNSUPPORTED_WITH_COMMIT);

PROCEDURE modifyparameter(paramname       IN VARCHAR2,
                          paramstr        IN CLOB);
PRAGMA SUPPLEMENTAL_LOG_DATA(modifyparameter, UNSUPPORTED_WITH_COMMIT);

PROCEDURE dropparameter(paramname       IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(dropparameter, UNSUPPORTED_WITH_COMMIT);

FUNCTION getparameter(paramname IN VARCHAR2) RETURN VARCHAR2;

end dbms_xmlindex;
/
