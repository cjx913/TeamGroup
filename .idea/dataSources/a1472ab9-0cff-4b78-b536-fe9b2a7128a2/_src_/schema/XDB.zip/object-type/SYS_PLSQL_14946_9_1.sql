CREATE type       SYS_PLSQL_14946_9_1 as table of VARCHAR2(4000);
/
