CREATE type     XMLIndexTab_t as TABLE of XDB.XMLIndexLoad_t
/
