CREATE type     xdb$xmltype_ref_list_t
                                       as varray(2147483647) of ref sys.xmltype;
/
