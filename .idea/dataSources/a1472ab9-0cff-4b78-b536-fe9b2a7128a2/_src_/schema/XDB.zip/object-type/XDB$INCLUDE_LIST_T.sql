CREATE type     xdb$include_list_t                                        as varray(65535) of xdb.xdb$include_t;
/
