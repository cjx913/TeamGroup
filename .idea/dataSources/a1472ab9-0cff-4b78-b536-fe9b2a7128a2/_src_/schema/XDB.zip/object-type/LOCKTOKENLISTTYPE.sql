CREATE type     LockTokenListType as varray(2147483647) of VARCHAR2(128)
/
