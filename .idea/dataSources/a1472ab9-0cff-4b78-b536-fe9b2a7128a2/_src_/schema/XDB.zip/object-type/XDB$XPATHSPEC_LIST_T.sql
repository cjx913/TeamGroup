CREATE type     xdb$xpathspec_list_t
                                      
as varray(1000) of xdb.xdb$xpathspec_t
/
