CREATE TYPE       "http-log45_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","http-log-entry" "http-log-entry46_COLL")FINAL INSTANTIABLE
/
