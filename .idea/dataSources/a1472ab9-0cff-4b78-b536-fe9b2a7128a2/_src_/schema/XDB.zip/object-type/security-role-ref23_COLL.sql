CREATE TYPE       "security-role-ref23_COLL" AS VARRAY(65535) OF "security-role-ref22_T"
/
