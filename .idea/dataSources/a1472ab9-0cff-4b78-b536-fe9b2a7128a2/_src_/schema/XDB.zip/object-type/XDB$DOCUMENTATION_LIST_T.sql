CREATE type     xdb$documentation_list_t                                       
  as varray(1000) of xdb.xdb$documentation_t;
/
