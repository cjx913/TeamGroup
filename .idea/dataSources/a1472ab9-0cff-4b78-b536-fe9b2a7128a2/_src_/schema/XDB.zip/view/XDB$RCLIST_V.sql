CREATE VIEW XDB$RCLIST_V AS (select rclist from xdb.xdb$root_info)
/
