CREATE VIEW DOCUMENT_LINKS2 AS SELECT
resid source_id,
any_path source_path,
(select
  resid
 from resource_view
 where equals_path(res, extractvalue(value(xl), '/*/@xlink:href', 'xmlns:xlink="http://www.w3.org/1999/xlink"')) = 1) target_id,
extractvalue(value(xl), '/*/@xlink:href', 'xmlns:xlink="http://www.w3.org/1999/xlink"') target_path
FROM
resource_view r,
table(xmlsequence(extract(res, '//*[@xlink:href]', 'xmlns:xlink="http://www.w3.org/1999/xlink"'))) xl
/
