CREATE TRIGGER "privilege155_TAB$xd"
AFTER UPDATE OR DELETE
  ON "privilege155_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','privilege155_TAB', :old.sys_nc_oid$, '03B433A9C3EB4C29A95FB852BDC6294E' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','privilege155_TAB', :old.sys_nc_oid$, '03B433A9C3EB4C29A95FB852BDC6294E', user ); END IF; END;
/
