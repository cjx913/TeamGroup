CREATE TRIGGER "fallback83_TAB$xd"
AFTER UPDATE OR DELETE
  ON "fallback83_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','fallback83_TAB', :old.sys_nc_oid$, 'CE587267267A4F21BA74257E9D0277BB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','fallback83_TAB', :old.sys_nc_oid$, 'CE587267267A4F21BA74257E9D0277BB', user ); END IF; END;
/
