CREATE TRIGGER "include68_TAB$xd"
AFTER UPDATE OR DELETE
  ON "include68_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','include68_TAB', :old.sys_nc_oid$, '106B5EAE1FF244B6AE210B98B6E08ADF' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','include68_TAB', :old.sys_nc_oid$, '106B5EAE1FF244B6AE210B98B6E08ADF', user ); END IF; END;
/
