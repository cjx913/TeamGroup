CREATE TRIGGER "fallback82_TAB$xd"
AFTER UPDATE OR DELETE
  ON "fallback82_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','fallback82_TAB', :old.sys_nc_oid$, '4E4C44612E58462681C0B392D7C21C68' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','fallback82_TAB', :old.sys_nc_oid$, '4E4C44612E58462681C0B392D7C21C68', user ); END IF; END;
/
