CREATE TRIGGER "XDB$RESCONFIG$xd"
AFTER UPDATE OR DELETE
  ON XDB$RESCONFIG
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'A4A4F45D526E40C9A9A0CF714F7D162C' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'A4A4F45D526E40C9A9A0CF714F7D162C', user ); END IF; END;
/
