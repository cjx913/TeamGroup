CREATE TRIGGER "XDB$STATS$xd"
AFTER UPDATE OR DELETE
  ON XDB$STATS
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$STATS', :old.sys_nc_oid$, '3610F712A5A24B04A632832692A6C0EA' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$STATS', :old.sys_nc_oid$, '3610F712A5A24B04A632832692A6C0EA', user ); END IF; END;
/
