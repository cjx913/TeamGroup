CREATE TRIGGER "SERVLET$xd"
AFTER UPDATE OR DELETE
  ON SERVLET
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','SERVLET', :old.sys_nc_oid$, '775733F9A29543BCAFCB58117BB84F09' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','SERVLET', :old.sys_nc_oid$, '775733F9A29543BCAFCB58117BB84F09', user ); END IF; END;
/
