CREATE TRIGGER "aggregatePrivilege156_TAB$xd"
AFTER UPDATE OR DELETE
  ON "aggregatePrivilege156_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','aggregatePrivilege156_TAB', :old.sys_nc_oid$, '5FA5E78F25CE4AACA8C51F3DCDA9C0BC' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','aggregatePrivilege156_TAB', :old.sys_nc_oid$, '5FA5E78F25CE4AACA8C51F3DCDA9C0BC', user ); END IF; END;
/
