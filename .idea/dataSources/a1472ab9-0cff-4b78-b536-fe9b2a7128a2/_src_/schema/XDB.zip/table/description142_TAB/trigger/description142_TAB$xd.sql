CREATE TRIGGER "description142_TAB$xd"
AFTER UPDATE OR DELETE
  ON "description142_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','description142_TAB', :old.sys_nc_oid$, '9D68821FAF544425916EB1E892AAB62A' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','description142_TAB', :old.sys_nc_oid$, '9D68821FAF544425916EB1E892AAB62A', user ); END IF; END;
/
