CREATE TRIGGER "fallback63_TAB$xd"
AFTER UPDATE OR DELETE
  ON "fallback63_TAB"
FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','fallback63_TAB', :old.sys_nc_oid$, 'D1BB51D420C440B4B646D4A618F0D461' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','fallback63_TAB', :old.sys_nc_oid$, 'D1BB51D420C440B4B646D4A618F0D461', user ); END IF; END;
/
